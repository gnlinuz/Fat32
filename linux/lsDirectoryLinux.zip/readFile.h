#ifndef READFILE_H
#define READFILE_H

#include "types.h"

int read_state(FAT32_CWDInfo *info);

#endif